import { strict as assert } from 'node:assert'
import { mkdtempSync, mkdirSync, symlinkSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import { adocFiles, collectBlocks, diagramType, extractBlocks, extractMarkdownBlocks, lintBlock, markdownFiles } from './blocks.mjs'

test('extracts literal and listing blocks with their first source line', () => {
  const text = ['= Page', '', '[mermaid]', '....', 'flowchart LR', '  A --> B', '....', '', '[mermaid,format=svg]', '', '----', 'graph TD', '----'].join('\n')
  assert.deepEqual(extractBlocks(text), [
    { line: 5, src: 'flowchart LR\n  A --> B' },
    { line: 12, src: 'graph TD' }
  ])
})

test('ignores a [mermaid] attribute without a delimited block and other block styles', () => {
  assert.deepEqual(extractBlocks('[mermaid]\ntext\n\n[source,mermaid]\n----\nA\n----'), [])
})

test('flags tag-like text but not Mermaid arrows', () => {
  assert.deepEqual(lintBlock('classDiagram\n  A <|-- B\n  C <--> D\n  E <<->> F'), [])
  assert.deepEqual(lintBlock('flowchart LR\n  A["one<br>two<br/>three <b>bold</b>"]'), [])
  const problems = lintBlock('flowchart LR\n  A["write <timestamp>"]\n  B["&amp;lt;ok&amp;gt;"]\n  class X <<interface>>')
  assert.deepEqual(problems.map((p) => p.offset), [1, 3])
})

test('flags a single-escaped placeholder inside a label, accepts the double-escaped one', () => {
  assert.deepEqual(lintBlock('flowchart LR\n  A["meeting-&lt;timestamp&gt;"]').map((p) => p.offset), [1])
  assert.deepEqual(lintBlock('flowchart LR\n  A["meeting-&amp;lt;timestamp&amp;gt;"]'), [])
  assert.deepEqual(lintBlock('classDiagram\n  class Shape {\n    &lt;&lt;interface&gt;&gt;\n  }'), [])
})

test('flags a single-escaped placeholder in every unquoted label form', () => {
  const lines = [
    'flowchart LR',
    '  A[iru-&lt;key&gt;-bump] --> B',
    '  A(run &lt;key&gt;) --> B',
    '  A{is &lt;key&gt; set} --> B',
    '  A([run &lt;key&gt;]) --> B',
    '  A -->|run &lt;key&gt; now| B',
    '  A -- run &lt;key&gt; --> B',
    '  A[iru-&amp;lt;key&amp;gt;-bump] -->|run &amp;lt;key&amp;gt;| B',
    '  %% a comment about &lt;key&gt;'
  ]
  assert.deepEqual(lintBlock(lines.join('\n')).map((p) => p.offset), [1, 2, 3, 4, 5, 6])
  assert.deepEqual(lintBlock('classDiagram\n  class Foo {\n    +List&lt;String&gt; items\n  }').map((p) => p.offset), [2])
  assert.deepEqual(lintBlock('classDiagram\n  Foo --> Bar : uses &lt;key&gt;').map((p) => p.offset), [1])
  assert.deepEqual(lintBlock('classDiagram\n  class Shape &lt;&lt;interface&gt;&gt;'), [])
})

test('accepts single-escaped text in sequence diagrams', () => {
  assert.deepEqual(lintBlock('sequenceDiagram\n  participant A as svc &lt;key&gt;\n  A->>B: get &lt;key&gt;'), [])
  assert.deepEqual(lintBlock('sequenceDiagram\n  A->>B: get <key>').map((p) => p.offset), [1])
})

test('asks to reword a placeholder in a stateDiagram label, either escaping', () => {
  const problems = lintBlock('stateDiagram-v2\n  s1 --> s2: on &lt;key&gt;\n  s2 --> s3: on &amp;lt;key&amp;gt;\n  state c &lt;&lt;choice&gt;&gt;')
  assert.deepEqual(problems.map((p) => p.offset), [1, 2])
  assert.match(problems[0].message, /reword/)
})

test('detects the diagram type past front matter and comments', () => {
  assert.equal(diagramType('---\ntitle: x\n---\n%% note\n\nsequenceDiagram\n  A->>B: hi'), 'sequenceDiagram')
  assert.equal(diagramType('flowchart LR'), 'flowchart')
  assert.equal(diagramType(''), '')
})

test('collects blocks from pages and partials', () => {
  const dir = mkdtempSync(join(tmpdir(), 'mermaid-blocks-'))
  mkdirSync(join(dir, 'ROOT', 'partials'), { recursive: true })
  writeFileSync(join(dir, 'ROOT', 'partials', 'p.adoc'), '[mermaid]\n....\ngraph LR\n....\n')
  writeFileSync(join(dir, 'ROOT', 'skip.txt'), '[mermaid]\n....\ngraph LR\n....\n')
  const blocks = collectBlocks(dir)
  assert.equal(blocks.length, 1)
  assert.match(blocks[0].file, /p\.adoc$/)
})

test('extracts Markdown mermaid fences with their first source line', () => {
  const text = ['# Doc', '', '```mermaid', 'flowchart LR', '  A --> B', '```', '', '~~~mermaid', 'graph TD', '~~~'].join('\n')
  assert.deepEqual(extractMarkdownBlocks(text), [
    { line: 4, src: 'flowchart LR\n  A --> B' },
    { line: 9, src: 'graph TD' }
  ])
})

test('Markdown fences: longer fence needs a matching close, other languages are ignored', () => {
  const text = ['````mermaid', 'graph TD', '```', 'A --> B', '````', '```js', 'x', '```', '```mermaidish', 'y', '```'].join('\n')
  assert.deepEqual(extractMarkdownBlocks(text), [{ line: 2, src: 'graph TD\n```\nA --> B' }])
})

test('Markdown fences are not mistaken for AsciiDoc blocks and vice versa', () => {
  assert.deepEqual(extractBlocks('```mermaid\ngraph TD\n```'), [])
  assert.deepEqual(extractMarkdownBlocks('[mermaid]\n....\ngraph TD\n....'), [])
})

test('collectBlocks reads .adoc and .md files and lints Markdown blocks like AsciiDoc ones', () => {
  const dir = mkdtempSync(join(tmpdir(), 'mermaid-md-'))
  writeFileSync(join(dir, 'a.adoc'), '[mermaid]\n....\ngraph TD\n....\n')
  writeFileSync(join(dir, 'b.md'), '```mermaid\nflowchart LR\n  A["write <timestamp>"]\n```\n')
  const blocks = collectBlocks(dir)
  assert.deepEqual(blocks.map((b) => [b.file.split('/').pop(), b.line]), [['a.adoc', 3], ['b.md', 2]])
  assert.deepEqual(lintBlock(blocks[1].src).map((p) => p.offset), [1])
})

test('file walk skips node_modules, build, dot directories and symlinked directories', () => {
  const dir = mkdtempSync(join(tmpdir(), 'mermaid-walk-'))
  for (const sub of ['node_modules/pkg', '.git', 'build/site', 'docs/modules', 'outside']) mkdirSync(join(dir, sub), { recursive: true })
  for (const file of ['node_modules/pkg/a.adoc', '.git/b.md', 'build/site/c.adoc', 'outside/d.adoc', 'docs/modules/e.adoc', 'docs/f.md', 'g.adoc']) {
    writeFileSync(join(dir, file), '')
  }
  symlinkSync(join(dir, 'outside'), join(dir, 'docs', 'linked'), 'dir')
  symlinkSync(dir, join(dir, 'docs', 'modules', 'cycle'), 'dir')
  const relative = (files) => files.map((f) => f.slice(dir.length + 1))
  assert.deepEqual(relative(adocFiles(join(dir, 'docs'))), ['docs/modules/e.adoc'])
  assert.deepEqual(relative(adocFiles(dir)), ['docs/modules/e.adoc', 'g.adoc', 'outside/d.adoc'])
  assert.deepEqual(relative(markdownFiles(dir)), ['docs/f.md'])
})

test('Markdown fences: a mermaid example inside another fence is not a diagram', () => {
  const text = [
    '````markdown', '```mermaid', 'graph TD', '```', '````',
    '~~~text', '```mermaid', 'graph LR', '```', '~~~',
    '```', '```mermaid', '```',
    '```mermaid', 'flowchart LR', '```',
    '```js', 'unclosed ```mermaid', '```mermaid'
  ].join('\n')
  assert.deepEqual(extractMarkdownBlocks(text), [{ line: 15, src: 'flowchart LR' }])
})

test('Markdown fences: an unclosed mermaid fence runs to the end of the file', () => {
  assert.deepEqual(extractMarkdownBlocks('```mermaid\ngraph TD\n  A --> B'), [{ line: 2, src: 'graph TD\n  A --> B' }])
})
